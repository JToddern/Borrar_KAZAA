#include <iostream>
#include <cmath>
#include  <iomanip>

const int MAX = 10000000; 
using  namespace  std;
int main()
{
double i = 0, seno,coseno,tangente, logaritmo, raidCuad;

while(i < MAX)
	{

		seno += sin(i);
		coseno +=  cos(i);
		tangente += tan(i);
		logaritmo +=  (log(i) / log(10));
		raidCuad += sqrt(i);
		i++;
	}
	cout << fixed << setprecision(16) <<"Seno = "<< seno << "Coseno = " << coseno << "Tangente = " << tangente << "Logaritmo = " << logaritmo <<  "Raiz = " << raidCuad << endl;
 return 0;
}
