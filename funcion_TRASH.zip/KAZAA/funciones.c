#include <stdlib.h>
#include <math.h>
#include <stdio.h>

const int MAX = 10000000;

int main()
{
double i = 0, seno,coseno,tangente, logaritmo, raidCuad;

while(i < MAX)
	{

		seno += sin(i);
		coseno +=  cos(i);
		tangente += tan(i);
		logaritmo +=  (log(i) / log(10));
		raidCuad += sqrt(i);
		i++;
	}
	printf("Seno = %f, Coseno = %f, Tangente  = %f, Logaritmo = %f RaizCuad = %f\n", seno,coseno,tangente,logaritmo,raidCuad);
 return 0;
}
