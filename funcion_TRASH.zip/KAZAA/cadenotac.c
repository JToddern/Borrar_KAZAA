#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

int main(){
char *cadenota = NULL;
int posicion = 1, i, x, cont = 0;
char *cadenaI = {"IPN "};
cadenota = (char *) malloc(posicion);
char cadena[3];
srand(time(NULL));

for(x=0; x<=150000000; x++){
	for(i=0; i<3; i++){		
		cadena[i]= 65 + rand()%(90-65);		
	}
	cadena[3]=' ';
	    memcpy(cadenota, cadena, 4);
		cadenota = (char *)realloc(cadenota, posicion);
		posicion++;
		//printf("String = %s,  Address = %u\n", cadenota, cadenota);
		//printf("%s ", cadenota);
		if (strcmp(cadenota,cadenaI) == 0)
		{
			cont++;
		}
}
printf("\n");
printf("Se encontro IPN = %d\n", cont);
free(cadenota);
return 0;
}
